export default {
    state: {
        loading: false
    },

    
    mutations: {
        LOADING (state, loading) {
            state.loading = loading
        }
    }
}