export default {
    items: {}
}