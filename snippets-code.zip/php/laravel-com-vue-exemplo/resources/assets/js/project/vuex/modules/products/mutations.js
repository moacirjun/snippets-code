export default {
    PRODUCTS_LOAD (state, products) {
        state.items = products
    }
}