<template>
  <div>
      #menu

      <hr>
        <router-view></router-view>
      <hr>

      #footer
  </div>
</template>
