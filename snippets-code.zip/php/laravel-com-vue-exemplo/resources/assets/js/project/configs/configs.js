export const URL_BASE = '/api/v1/'
export const NAME_TOKEN = 'auth_token'