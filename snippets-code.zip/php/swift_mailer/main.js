var form = document.querySelector('.form-mail');
form.addEventListener('submit', (event) => {
    event.preventDefault();
    alert("opa");
});