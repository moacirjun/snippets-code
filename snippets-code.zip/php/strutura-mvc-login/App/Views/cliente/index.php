<h1>Cliente</h1>
<ul id="sidebar-cliente">
    <li>Painel</li>
    <li>Pedidos</li>
    <li>Endereços</li>
    <li>Detalhes da conta</li>
    <li>Torne-se um vendedor</li>
    <li>Sair</li>
</ul>