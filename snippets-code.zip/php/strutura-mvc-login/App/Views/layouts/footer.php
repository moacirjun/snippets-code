
    <footer class="container">
    </footer>

    <script src="http://<?php echo APP_HOST; ?>/public/js/main.js"></script>
</body>
