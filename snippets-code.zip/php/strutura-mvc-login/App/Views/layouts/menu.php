<nav>
    <ul id="menu">
        <li>Home</li>
        <li>Segmentos</li>
        <li>Instituições</li>
        <li>Atividades</li>
        <li>Jovens</li>
    </ul>
</nav>