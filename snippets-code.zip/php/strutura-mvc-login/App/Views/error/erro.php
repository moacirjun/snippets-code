<main id="main-content">
    <section id="wrapper">
        <header>
            Erro <?php echo $errorCode; ?>
        </header>
        <div>  
            <?php echo $errorMessage; ?>            
        </div>
    </section>
</main>