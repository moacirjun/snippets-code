-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 21-Ago-2018 às 03:38
-- Versão do servidor: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assadores_v2`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_avaliacoes`
--

CREATE TABLE `tb_avaliacoes` (
  `id` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `data_avaliacao` date NOT NULL,
  `valor_avaliacao` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_categorias`
--

CREATE TABLE `tb_categorias` (
  `id` int(11) NOT NULL,
  `id_pai` int(11) NOT NULL,
  `nome` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_categorias_opcoes`
--

CREATE TABLE `tb_categorias_opcoes` (
  `id` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `id_opcoes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cupons`
--

CREATE TABLE `tb_cupons` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `tipo` tinyint(1) NOT NULL,
  `valor` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_opcoes`
--

CREATE TABLE `tb_opcoes` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_pedidos`
--

CREATE TABLE `tb_pedidos` (
  `id` int(11) NOT NULL,
  `id_cupom` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `pagamento_tipo` tinyint(1) NOT NULL,
  `pagamento_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_pedidos_pagamentos`
--

CREATE TABLE `tb_pedidos_pagamentos` (
  `id` int(11) NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `valor` float NOT NULL,
  `codigo_trasacao` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_pedidos_produtos`
--

CREATE TABLE `tb_pedidos_produtos` (
  `id` int(11) NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `qtde` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_produtos`
--

CREATE TABLE `tb_produtos` (
  `id` int(11) NOT NULL,
  `id_vendedor` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `descricao` text NOT NULL,
  `preco` float NOT NULL,
  `preco_comparar` float DEFAULT NULL,
  `estoque` float NOT NULL,
  `avaliacao_media` double DEFAULT NULL,
  `promocao` tinyint(1) NOT NULL,
  `destaque` tinyint(1) NOT NULL,
  `mais_vendido` tinyint(1) NOT NULL,
  `novo_produto` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_produtos_imagens`
--

CREATE TABLE `tb_produtos_imagens` (
  `id` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `url` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_produtos_opcoes`
--

CREATE TABLE `tb_produtos_opcoes` (
  `id` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `id_opcao` int(11) NOT NULL,
  `valor` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_usuarios`
--

CREATE TABLE `tb_usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(250) NOT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `login` varchar(100) NOT NULL,
  `senha` varchar(32) NOT NULL,
  `tipo` tinyint(1) NOT NULL,
  `email_moip` varchar(100) DEFAULT NULL,
  `numero_banco` varchar(15) DEFAULT NULL,
  `numero_conta` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_usuarios`
--

INSERT INTO `tb_usuarios` (`id`, `nome`, `rg`, `cpf`, `telefone`, `email`, `login`, `senha`, `tipo`, `email_moip`, `numero_banco`, `numero_conta`) VALUES
(1, 'Moacir', '2520490-4', '02243432200', '092982438992', 'moacirjunior.eletro@gmail.com', 'moacirjun', 'juninho2122', 1, NULL, NULL, NULL),
(2, 'Fernado', '255478346', '04876221358', '92982754816', 'fernando@gmail.com', 'fernando', '123', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_usuarios_enderecos`
--

CREATE TABLE `tb_usuarios_enderecos` (
  `id` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `cep` varchar(20) NOT NULL,
  `estado` varchar(100) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `logradouro` varchar(100) NOT NULL,
  `numero` varchar(15) NOT NULL,
  `complemento` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_avaliacoes`
--
ALTER TABLE `tb_avaliacoes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_categorias`
--
ALTER TABLE `tb_categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_categorias_opcoes`
--
ALTER TABLE `tb_categorias_opcoes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_cupons`
--
ALTER TABLE `tb_cupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_opcoes`
--
ALTER TABLE `tb_opcoes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_pedidos`
--
ALTER TABLE `tb_pedidos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_pedidos_pagamentos`
--
ALTER TABLE `tb_pedidos_pagamentos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_pedidos_produtos`
--
ALTER TABLE `tb_pedidos_produtos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_produtos`
--
ALTER TABLE `tb_produtos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_produtos_imagens`
--
ALTER TABLE `tb_produtos_imagens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_produtos_opcoes`
--
ALTER TABLE `tb_produtos_opcoes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_usuarios`
--
ALTER TABLE `tb_usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_usuarios_enderecos`
--
ALTER TABLE `tb_usuarios_enderecos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_avaliacoes`
--
ALTER TABLE `tb_avaliacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_categorias`
--
ALTER TABLE `tb_categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_categorias_opcoes`
--
ALTER TABLE `tb_categorias_opcoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_cupons`
--
ALTER TABLE `tb_cupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_opcoes`
--
ALTER TABLE `tb_opcoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_pedidos`
--
ALTER TABLE `tb_pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_pedidos_pagamentos`
--
ALTER TABLE `tb_pedidos_pagamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_pedidos_produtos`
--
ALTER TABLE `tb_pedidos_produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_produtos`
--
ALTER TABLE `tb_produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_produtos_imagens`
--
ALTER TABLE `tb_produtos_imagens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_produtos_opcoes`
--
ALTER TABLE `tb_produtos_opcoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_usuarios`
--
ALTER TABLE `tb_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_usuarios_enderecos`
--
ALTER TABLE `tb_usuarios_enderecos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
