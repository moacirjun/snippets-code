#SNIPPETS-CODE
    - Meus trechos de códigos das linguagens que mais uso. Quero guardar isso num lugar de fácil acesso e seguro, e claro, ajudar a comunidade  de DEVs.